import tkinter as tk
 
root = tk.Tk()
 
var = tk.IntVar()
r1 = tk.Radiobutton(root, text='Option 1', variable=var, value=1)
r1.pack(anchor='w')
 
r2 = tk.Radiobutton(root, text='Option 2', variable=var, value=2)
r2.pack(anchor='w')
r2.invoke()
 
r3 = tk.Radiobutton(root, text='Option 3', variable=var, value=3)
r3.pack(anchor='w')
 
root.mainloop()