import os
import time
import win32com.client
from tkinter import *
from tkinter import ttk
import openpyxl
from openpyxl import Workbook, load_workbook

# Transação: CS02
# Lista exemplo: 11800658
# ECM exemplo: 500002229360

# Carrega a planilha resposta
try:
    pa = load_workbook('planilha_resposta_mat_000.xlsx')
except:
    print('Erro ao carregar planilha resposta. Fechando planilha...')

# Seleciona aba da folha resposta
aba_pa = pa['Folha_resposta']

#aba_pa['D'+str(i)].value

for i in range(530):
    if type(aba_pa['E'+str(i+1)].value) == int and len(str(aba_pa['E'+str(i+1)].value)) == 8:
        print(aba_pa['E'+str(i+1)].value)
        


    time.sleep(0.01)



