from tkinter import *
from tkinter import ttk
import openpyxl
from openpyxl import Workbook, load_workbook

'''
# Carregando uma planilha já existente (bd = banco de dados)
bd = load_workbook('1_Banco_de_dados_Planilha_Auxiliar.xlsx')

# Pegando a aba atualmente ativa
#aba_ativa = planilha.active

# Pegando uma aba específica (exemplo: aba1)
aba_1 = bd['aba1']

# Lendo uma célula em específico
print(aba_1['C2'].value)

# Escrever em uma célula em específico
aba_1['B6'].value = 10

# Excluindo linhas em lote


# Salvando a planilha em outro arquivo diferente (basta salvar com outro nome)
bd.save('exemplo_resultado.xlsx')
'''
#=======================================================================================================

'''# Código para imprimir as posições da lista técnica na planilha resposta
incremento = 5
pos_inic = 1000
celulas = 'E' + str(246)

for m in range(14):
    aba_pa[celulas].value = pos_inic + (m * incremento)
    #res = pos_inic + (m * incremento)
    celulas = 'E' + str(246 + m)
    #print(res)'''

#=======================================================================================================

'''# Colocando texto pre-definido no campos de texto
from tkinter import *
win = Tk()
win.geometry("700x250")

def temp_text(e):
   textbox.delete(0,"end")

textbox = Entry(win, bg="white", width=50, borderwidth=2)
textbox.insert(0, "Digite o nome do projeto...")
textbox.place(x=200, y=20)
textbox.bind("<FocusIn>", temp_text)

win.mainloop()'''

#=======================================================================================================

'''# Limitando usuário a digitar somente inteiros
import tkinter as tk
from tkinter import ttk


def is_type_int(*args):
    item = var.get()
    try:
        item_type = type(int(item))
        if item_type == type(int(1)):
            print(item)
            print(item_type)
    except:
        ent.delete(0, tk.END)


root = tk.Tk()
root.geometry("300x300")

var = tk.StringVar()

ent = ttk.Entry(root, textvariable=var)
ent.pack(pady=20)

var.trace("w", is_type_int)

root.mainloop()'''

#=======================================================================================================

'''# Deletando linhas
import openpyxl as xl
from tkinter import *
from tkinter import ttk, filedialog
import openpyxl
from openpyxl import Workbook, load_workbook

wb = xl.load_workbook('2_Interface Base_campos_folha_testes.xlsx')
ws = wb.active
ws.delete_rows(307, 17) #for multiple row deletion
#ws.delete_rows(rownum) #for single row

wb.save('C:/Users/duartec/Desktop/TESTES/planilha_auxiliar_v2exemplo_resultado.xlsx')'''

#=======================================================================================================

# Ativa/desativa um menu quando selecionado certa opção em outro menu
from tkinter import *

# Create an instance of tkinter frame
root = Tk()
root.geometry("700x300")

# Create the option and Check Button Event
def test(event):
    if var1.get()=='Mumbai':
        b.configure(state='disabled')
    else:
        b.configure(state='normal')

# criando menu 1
var1 = StringVar()
var1.set("Menu 1")

options = ["Mumbai", "Chennai"]
a = OptionMenu(root, var1, *options, command=test)
a.place(x=200, y=50)

# criando menu 2
var2 = StringVar()
var2.set("Menu 2")

options2 = ["Mumbai", "Chennai"]
b = OptionMenu(root, var2, *options2)
b.place(x=200, y=100)

root.mainloop()

#======================================================================================================

# Código para ocultar linhas de planilhas excel
pa = load_workbook('testes.xlsx')
aba_pa = pa['Folha_resposta']

# Linhas a serem ocultadas por padrão
aba_pa.row_dimensions.group(25, 28, hidden=True)
aba_pa.row_dimensions.group(91, 140, hidden=True)
aba_pa.row_dimensions.group(191, 241, hidden=True)
aba_pa.row_dimensions.group(451, 487, hidden=True)
aba_pa.row_dimensions.group(525, 528, hidden=True)

if aba_pa['D'+str(11)].value == '*':
   aba_pa.row_dimensions.group(10, 14, hidden=True)

if aba_pa['D'+str(16)].value == '*':
   aba_pa.row_dimensions.group(15, 19, hidden=True)


pa.save("linhas_ocultadas.xlsx")



