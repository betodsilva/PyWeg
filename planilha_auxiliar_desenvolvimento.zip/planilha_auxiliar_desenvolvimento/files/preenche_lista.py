import win32com.client
from tkinter import *
from tkinter import ttk
import openpyxl
from openpyxl import Workbook, load_workbook

material = "11800658"
ecm = "500002229360"

# Carrega a planilha resposta
try:
    pa = load_workbook('planilha_resposta_mat_000.xlsx')
except:
    print('Erro ao carregar planilha resposta. Fechando planilha...')

# Seleciona aba da folha resposta
aba_pa = pa['Folha_resposta']

# Inicia conexão no SAP
SapGui = win32com.client.GetObject("SAPGUI").GetScriptingEngine
session = SapGui.FindById("ses[0]")

# Acessa a Lista técnica
session.findById("wnd[0]").maximize
session.findById("wnd[0]/tbar[0]/okcd").text = "/NCS02"
session.findById("wnd[0]/tbar[0]/btn[0]").press()
session.findById("wnd[0]/usr/ctxtRC29N-MATNR").text = material
session.findById("wnd[0]/usr/ctxtRC29N-STLAN").text = "1"
session.findById("wnd[0]/usr/ctxtRC29N-AENNR").text = ecm
session.findById("wnd[0]/usr/ctxtRC29N-AENNR").setFocus
session.findById("wnd[0]/usr/ctxtRC29N-AENNR").caretPosition = 12
session.findById("wnd[0]").sendVKey(0)
session.findById("wnd[0]").sendVKey(0)
session.findById("wnd[1]").sendVKey(0)
session.findById("wnd[0]").sendVKey(0)

for i in range(530):
    if type(aba_pa['E'+str(i+1)].value) == int and len(str(aba_pa['E'+str(i+1)].value)) == 8 and float(aba_pa['H'+str(i+1)].value) > 0:

            # Leva o cursor para o final da lista
            session.findById("wnd[0]/tbar[1]/btn[5]").press()

            # Insere as posições na lista técnica
            session.findById("wnd[0]/usr/tabsTS_ITOV/tabpTCMA/ssubSUBPAGE:SAPLCSDI:0152/tblSAPLCSDITCMAT/txtRC29P-POSNR[0,1]").text = aba_pa['D'+str(i+1)].value
            session.findById("wnd[0]/usr/tabsTS_ITOV/tabpTCMA/ssubSUBPAGE:SAPLCSDI:0152/tblSAPLCSDITCMAT/ctxtRC29P-IDNRK[1,1]").text = aba_pa['E'+str(i+1)].value
            session.findById("wnd[0]/usr/tabsTS_ITOV/tabpTCMA/ssubSUBPAGE:SAPLCSDI:0152/tblSAPLCSDITCMAT/txtRC29P-MENGE[3,1]").text = aba_pa['H'+str(i+1)].value
            session.findById("wnd[0]/usr/tabsTS_ITOV/tabpTCMA/ssubSUBPAGE:SAPLCSDI:0152/tblSAPLCSDITCMAT/ctxtRC29P-POSTP[5,1]").text = "L"
            session.findById("wnd[0]").sendVKey(0)



