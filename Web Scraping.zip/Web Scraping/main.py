# Lembrar:
# Instalar programa python em python.org
# Instalar um editor de códigos, como VSCode (recomendo) e PyCharm
# Baixar o Chrome driver e extrair o arquivo .exe para a mesma pasta onde está
# salvo este programa (main.py)
# Link para baixar o Chrome Driver: https://chromedriver.chromium.org/downloads
# Instalar a biblioteca Selenium: escrever no terminal "pip install selenium"
# Intalar a biblioteca pygame

import time
from pygame import mixer
from datetime import datetime
from selenium import webdriver
from selenium.webdriver.chrome.service import Service

alarme = 'ligado'
envio_email = 'ativado'
disparos_alarme = 5

# Loop infinito
while True:
    email = 'duvidaecontato@gmail.com' # Local para inserir o e-mail
    senha = '156324iT'                 # Local para inserir a senha

    # Executando o navegador
    opcoes = webdriver.ChromeOptions() 
    opcoes.add_experimental_option("excludeSwitches", ["enable-logging"])

    navegador = webdriver.Chrome(options=opcoes, service=Service('C:/Users/Carlos/Desktop/Web Scraping/chromedriver.exe'))   # Caminho PC pessoal
    #navegador = webdriver.Chrome(options=opcoes, service=Service('C:/Users/duartec/Desktop/Web Scraping/chromedriver.exe'))   # Caminho PC WEG

    # Setando uma página da web
    try:
        navegador.get('https://prenotami.esteri.it/')
        conexao = 'online'
    except:
        conexao = 'offline'
        print('Você está sem conexão com a internet ou o site está fora do ar.')

    # Tela 1: insere e-mail e senha e clica no botão "Avanti"
    if conexao == 'online':
        time.sleep(3)
        try:
            login = navegador.find_element("xpath",'//*[@id="login-email"]').send_keys(email)
            tela1 = 'ok'
        except:
            tela1 = 'erro'
            print('Erro ao inserir e-mail')

        try:
            password = navegador.find_element("xpath",'//*[@id="login-password"]').send_keys(senha)
            tela1 = 'ok'
        except:
            tela1 = 'erro'
            print('Erro ao inserir senha')

        try:
            clique = navegador.find_element("xpath",'//*[@id="login-form"]/button').click()
            tela1 = 'ok'
        except:
            tela1 = 'erro'
            print('Erro ao clicar no botão "Avanti"')

    # Tela 2: Clicando na aba "Reservar"
    if tela1 == 'ok':
        time.sleep(3)
        try:
            clique = navegador.find_element("xpath",'//*[@id="advanced"]/span').click()
            tela2 = 'ok'
        except:
            tela2 = 'erro'
            print('Erro ao tentar acessar a página de reservas.')
        
    #Tela 3: Clicando no botão "Reservar"
    if tela2 == 'ok':
        time.sleep(3)
        try:
            clique = navegador.find_element("xpath", '//*[@id="dataTableServices"]/tbody/tr[2]/td[4]/a/button').click()
            tela3 = 'ok'
        except:
            tela3 = 'erro'
            print('Erro ao tentar clicar no botão "Reservar"')
    
    # Tela 4: Verificando se há vagas disponíveis
    resultado = ''
    if tela3 == 'ok':
        time.sleep(3)
        try:
            resultado = navegador.find_element("xpath",'/html/body/div[2]/div[2]/div/div/div/div/div/div/div/div[4]/button').text
        except:
            print('Não foi possível obter informações.')

    if resultado == 'OK':
        # Fecha o navegador, pois não há vagas disponíveis
        print('RESULTADO: Não há vagas disponíveis')
        #navegador.quit()
    else:
        '''# Chamando a data e a hora atual
        data_hora = datetime.now()
        texto_data_hora = data_hora.strftime('%d/%m/%Y %H:%M')
        print('Acesso dia ' + texto_data_hora + ' Horas')

        # Edita o txt com o horário de liberação das vagas
        resultados = open('resultados.txt', 'a')
        resultados.write('\nATENÇÂO: \nFoi identificado uma possível liberação de vagas no dia ' + texto_data_hora + ' Horas.\n')
        resultados.close()'''

        # Dispara o alarme avisando que pode haver vagas disponíveis
        if alarme == 'ligado':
            for x in range(disparos_alarme):
                mixer.init()
                mixer.music.load("alarme.mp3")
                mixer.music.play()
                time.sleep(10)
        
        # Envia email avisando que pode haver vagas disponíveis
        if envio_email == 'ativado':
            pass


        #========================================================
        #           Implementar envio de email aqui
        #========================================================



        # Intervalo de 1 hora para entre os disparos de alarme/e-mail
        time.sleep(3600)

    # Intervalo de 60 segundos entre uma execução e outra
    time.sleep(30)

