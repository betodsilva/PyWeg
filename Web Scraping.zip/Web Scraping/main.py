# Lembrar:
# Instalar programa python em python.org
# Instalar um editor de códigos, como VSCode (recomendo) e PyCharm
# Baixar o Chrome driver e extrair o arquivo .exe para a mesma pasta onde está
# salvo este programa (main.py)
# Link para baixar o Chrome Driver: https://chromedriver.chromium.org/downloads
# Instalar a biblioteca Selenium: escrever no terminal "pip install selenium"
# Intalar a biblioteca pygame: escrever no terminal "pip install pygame"
# Configurar conta de e-mail Gmail para permitir login. Segue link com tutorial:
# https://www.hashtagtreinamentos.com/envio-de-e-mail-pelo-gmail-em-python

# Importando as bibliotecas
import time
import smtplib
import email.message
from pygame import mixer
from datetime import datetime
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options

# Loop infinito
while True:
    #===================================================================
    # Preencher as variáveis abaixo com as senhas, emails e preferências
    #===================================================================

    # "True" desabilita abertura do Chrome, "False" habilita
    desabilitar_navegador = True

    # Seta alarme como ligado/desligado
    alarme = 'ligado'

    # Seta envio de email como ativado/desativado
    envio_email = 'ativado'

    # Seta o número de disparos do alarme
    disparos_alarme = 5

    # Seta o tempo entre envios de emails de aviso
    tempo_entre_emails = 3600

    # Seta o tempo entre verificações de existência de vagas no site
    tempo_entre_verificacoes = 30

    # E-mail para envio de aviso de existência de vagas
    endereco_email_aviso = 'email_aviso.1@gmail.com'

    # Senha do e-mail para envio de aviso de existência de vagas
    senha_email_aviso = '123456789'

    # Variável contendo o e-mail para acessar o site da embaixada
    email_login_site = 'email_login@gmail.com'

    # Variável contendo a senha de acesso ao site da embaixada
    senha_login_site = '123456789'

    # Executando o navegador
    opcoes = webdriver.ChromeOptions()
    opcoes.headless = desabilitar_navegador
    opcoes.add_experimental_option("excludeSwitches", ["enable-logging"])

    # Inserindo o caminho onde se encontra o aplicativo chromedriver.exe (atentar para o tipo correto de "/")
    navegador = webdriver.Chrome(options=opcoes, service=Service('C:/Users/Carlos/Desktop/Web Scraping/chromedriver.exe'))# Caminho PC pessoal
    #navegador = webdriver.Chrome(options=opcoes, service=Service('C:/Users/duartec/Desktop/Web Scraping/chromedriver.exe'))# Caminho PC WEG

    # Setando uma página da web
    try:
        navegador.get('https://prenotami.esteri.it/')
        conexao = 'online'
    except:
        conexao = 'offline'
        print('Você está sem conexão com a internet ou o site está fora do ar.')

    # Tela 1: insere e-mail e senha e clica no botão "Avanti"
    if conexao == 'online':
        time.sleep(3)
        try:
            login = navegador.find_element("xpath",'//*[@id="login-email"]').send_keys(email_login_site)
            tela1 = 'ok'
        except:
            tela1 = 'erro'
            print('Erro ao inserir e-mail')

        try:
            password = navegador.find_element("xpath",'//*[@id="login-password"]').send_keys(senha_login_site)
            tela1 = 'ok'
        except:
            tela1 = 'erro'
            print('Erro ao inserir senha')

        try:
            clique = navegador.find_element("xpath",'//*[@id="login-form"]/button').click()
            tela1 = 'ok'
        except:
            tela1 = 'erro'
            print('Erro ao clicar no botão "Avanti"')

        # Tela 2: Clicando na aba "Reservar"
        if tela1 == 'ok':
            time.sleep(3)
            try:
                clique = navegador.find_element("xpath",'//*[@id="advanced"]/span').click()
                tela2 = 'ok'
            except:
                tela2 = 'erro'
                print('Erro ao tentar acessar a página de reservas.')
            
        #Tela 3: Clicando no botão "Reservar"
        if tela2 == 'ok':
            time.sleep(3)
            try:
                clique = navegador.find_element("xpath", '//*[@id="dataTableServices"]/tbody/tr[2]/td[4]/a/button').click()
                tela3 = 'ok'
            except:
                tela3 = 'erro'
                print('Erro ao tentar clicar no botão "Reservar"')
        
        # Tela 4: Verificando se há vagas disponíveis
        resultado = ''
        if tela3 == 'ok':
            time.sleep(3)
            try:
                resultado = navegador.find_element("xpath",'/html/body/div[2]/div[2]/div/div/div/div/div/div/div/div[4]/button').text
            except:
                resultado = 'erro'
                print('Não foi possível obter informações sobre vagas.')

        if resultado == 'OK':
            # Fecha o navegador, pois não há vagas disponíveis
            print('RESULTADO: Não há vagas disponíveis')
        
        elif resultado == 'erro':
            print('Erro ao tentar obter informações sobre vagas diponíveis.')
        
        else:
            # Envia email avisando que podem haver vagas disponíveis
            if envio_email == 'ativado':
                corpo_email = """
                <p>ATENÇÃO:</p>
                <p>Foram liberadas vagas para aplicação de cidadania italiana no site.</p>
                <p>Acesse: https://prenotami.esteri.it</p>
                """
                msg = email.message.Message()
                msg['Subject'] = "Vagas abertas para aplicação de cidadania italiana!"
                msg['From'] = endereco_email_aviso
                msg['To'] = endereco_email_aviso
                msg.add_header('Content-Type', 'text/html')
                msg.set_payload(corpo_email )

                s = smtplib.SMTP('smtp.gmail.com: 587')
                s.starttls()

                s.login(msg['From'], senha_email_aviso)
                s.sendmail(msg['From'], [msg['To']], msg.as_string().encode('utf-8'))
            
            # Dispara o alarme avisando que pode haver vagas disponíveis
            if alarme == 'ligado':
                for x in range(disparos_alarme):
                    mixer.init()
                    mixer.music.load("alarme.mp3")
                    mixer.music.play()
                    time.sleep(10)

            print('Vagas encontradas. Acesse o site imediatamente.')

            # Intervalo de tempo entre os disparos de alarme/e-mail
            time.sleep(tempo_entre_emails)

    # Intervalo de tempo entre um acesso ao site e outro
    time.sleep(tempo_entre_verificacoes)

