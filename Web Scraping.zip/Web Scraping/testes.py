import smtplib
import email.message

'''
# Chamando a data e a hora atual
data_hora = datetime.now()
texto_data_hora = data_hora.strftime('%d/%m/%Y %H:%M')
print('Acesso dia ' + texto_data_hora + ' Horas')

# Edita o txt com o horário de liberação das vagas
resultados = open('resultados.txt', 'a')
resultados.write('\nATENÇÂO: \nFoi identificado uma possível liberação de vagas no dia ' + texto_data_hora + ' Horas.\n')
resultados.close()
'''

def enviar_email():  
    corpo_email = """
    <p>ATENÇÃO:</p>
    <p>Foram liberadas vagas para aplicação de cidadania italiana no site.</p>
    <p>Acesse: https://prenotami.esteri.it</p>
    """

    msg = email.message.Message()
    msg['Subject'] = "Vagas abertas para aplicação de cidadania italiana!"
    msg['From'] = 'betoduarte11.1@gmail.com'
    msg['To'] = 'betoduarte11.1@gmail.com'
    password = 'iabxfvoykhtuisiv' 
    msg.add_header('Content-Type', 'text/html')
    msg.set_payload(corpo_email )

    s = smtplib.SMTP('smtp.gmail.com: 587')
    s.starttls()

    # Login Credentials for sending the mail
    s.login(msg['From'], password)
    s.sendmail(msg['From'], [msg['To']], msg.as_string().encode('utf-8'))
    print('Email enviado')

enviar_email()