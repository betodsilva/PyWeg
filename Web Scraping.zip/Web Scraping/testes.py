import time
from pygame import mixer

for x in range(3):
    mixer.init()
    mixer.music.load("alarme.mp3")
    mixer.music.play()
    time.sleep(10)


