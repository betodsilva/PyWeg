import os
import PyPDF2
import pandas as pd
from openpyxl import load_workbook

class Compilador:
    def __init__(self, nCliente, nObra, nTurb, ovTurb, nExec, nVerif, dProj, dVer, dCver, cLitro, docOv, pastaEsc):
        self.nCliente = nCliente
        self.nObra = nObra
        self.nTurb = nTurb
        self.ovTurb = ovTurb
        self.nExec = nExec
        self.nVerif = nVerif
        self.dProj = dProj
        self.dVer = dVer
        self.dCver = dCver
        self.cLitro = cLitro
        self.docOv = docOv
        self.pastaEsc = pastaEsc

    def lerPdf(self):
        # Lendo planilha excel baixada do SAP
        df = pd.read_excel(os.path.dirname(self.docOv) + '/export.XLSX')

        # Inicialização das variáveis
        t = ''
        valor = ''
        dados = {}
        caracteres = ['.', '-', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
        grandezas = ['#Potência', '#Nív de montante normal', '#Nív de jusante normal', 
                '#Afogamento (HS) requerido', '#Queda líquida nominal', '#Vazão nominal', '#Rotação nominal', 
                '#Sobrepressão', '#Sobrevelocidade', '#Tempo de fecham distribuidor', '#Rendimento turbina', '#Queda bruta']

        corteTurb = ['TURBINA FRANCIS', 'Turbina Francis', 'turbina francis', 'CORTE TURBINA', 'Corte Turbina', 'corte turbina', 'CORTE DA TURBINA', 'Corte Da Turbina', 'corte da turbina']
        arranjoGer = ['ARRANJO GERAL']
        qtt = ['INSTRUMENTAÇÃO DA TURBINA', 'QUADRO DE TERMINAIS DA TURBINA', 'Instrumentação Da Turbina', 'instrumentação da turbina', 'instrumentacao da turbina', 'Instrumentacao Da Turbina', ]
        valvBor = ['VÁLVULA BORBOLETA', 'Válvula Borboleta', 'válvula borboleta', 'Valvula Borboleta', 'VALVULA BORBOLETA', 'valvula borboleta']
        succao = ['SISTEMA SUCÇÃO', 'SISTEMA SUCCAO', 'sistema succao', 'Sistema Succao']
        preDist = ['SISTEMA PRÉ-DISTRIBUIDOR', 'SISTEMA PRE-DISTRIBUIDOR', 'Sistema Pré-Distribuidor', 'Sistema Pre-Distribuidor', 'sistema pré-distribuidor', 'sistema pre-distribuidor', 'SISTEMA PRE-DISTRIB' ]
        dist = ['SISTEMA DISTRIBUIDOR', 'Sistema Distribuidor', 'sistema distribuidor', 'SISTEMA DISTRIB', 'Sistema Distrib', 'sistema distrib']
        linhaEixo = ['LINHA DE EIXO','ROTOR - CONJUNTO', 'Linha De Eixo', 'linha de eixo', 'Rotor - Conjunto']
        vedEixo = ['VEDAÇÃO DO EIXO', 'Vedação do Eixo', 'vedação do eixo', 'VEDACAO DO EIXO', 'Vedacao do Eixo', 'vedacao do eixo']
        manMont = ['MANUAL DE MONTAGEM', 'Manual De Montagem', 'manual de montagem']
        manCom = ['MANUAL DE COMISSIONAMENTO', 'Manual De Comissionamento', 'manual de comissionamento']
        descParadPart = ['PARTIDA E PARADA', 'Parada E Partida', 'parada e partida' ]
        manOpeManut = ['MANUAL DE OPERAÇÃO E MANUTENÇÃO', 'Operação E Manutenção', 'Operacao E Manutencao', 'operação e manutenção', 'operacao e manutencao', 'MANUAL OPERAÇÃO E MANUTENÇÃO', 'Manual Operação e Manutenção']
        diagHidUHRV = ['UHRV - DIAGRAMA HIDRÁULICO', 'UHRV - Diagrama Hidráulico', 'UHRV - diagrama hidraulico']
        esqEletUHRV = ['UHRV - ESQUEMA ELÉTRICO', 'UHRV - Esquema Elétrico', 'UHRV - esquema eletrico']
        descFuncUHRV = ['UHRV - DESCRITIVO DE FUNCIONAMENTO', 'UHRV - Descritivo', 'UHRV - descritivo']
        skid = ['CONJUNTO PLACA DE ANCORAGEM']

        # Carregando planilha excel de saída
        saida = load_workbook('planilha_resposta_vazia.xlsx')
        abaP2 = saida['P2']

        # Imprimindo os campos do formulário de 'Informações do Projeto' na planilha resposta
        abaP2['B2'].value = self.nCliente
        abaP2['B3'].value = self.nObra
        abaP2['B4'].value = self.nTurb
        abaP2['B5'].value = self.ovTurb
        abaP2['B6'].value = self.nExec
        abaP2['B7'].value = self.nVerif
        abaP2['B8'].value = self.dProj
        abaP2['B9'].value = self.dVer
        abaP2['B10'].value = self.dCver
        abaP2['B28'].value = self.cLitro

        # Carregando o arquivo da OV em pdf
        pdfFileObj = open(self.docOv, 'rb') # Aqui falta usar o caminho informado pelo usuário
        
        # Lendo o arquivo pdf
        pdfReader = PyPDF2.PdfFileReader(pdfFileObj)
        qtyPages = pdfReader.numPages
        
        # Exptraindo o texto das páginas e compilando
        for i in range(qtyPages - 3):
            pageObj = pdfReader.getPage(i)
            textoPagina = pageObj.extractText()
            t = t + textoPagina

        # Localizando as grandezas no texto e pegando os valores respectivos
        for j in grandezas:
            pos = t.find(j)
            tam = len(j)
            valor = t[pos+tam]+t[pos+tam+1]+t[pos+tam+2]+t[pos+tam+3]+t[pos+tam+4]+t[pos+tam+5]+t[pos+tam+6]+t[pos+tam+7]+t[pos+tam+8]+t[pos+tam+9]
            valorTratado = ''
            for k in valor:
                if k in caracteres:
                    valorTratado = valorTratado + k
            dados[j] = valorTratado

        # Calculando os tempos de abetura e fechamento do distribuidor e da VB
        tempoAbertDist = 2 * float(dados['#Tempo de fecham distribuidor'])
        tempoAbertVB = 5 * float(dados['#Tempo de fecham distribuidor'])
        tempoFechVB = 5 * float(dados['#Tempo de fecham distribuidor'])

        # Adicionado tempoAbertDist, tempoAbertVB e tempoFechVB ao dicionário dados
        dados['#Tempo abertura distribuidor'] = tempoAbertDist
        dados['#Tempo abertura VB'] = tempoAbertVB
        dados['#Tempo fechamento VB'] = tempoFechVB

        # Calculando os percentuais de rotação e imprimindo na tabela
        rotacao25 = 0.25 * float(dados['#Rotação nominal'])
        rotacao50 = 0.50 * float(dados['#Rotação nominal'])
        rotacao75 = 0.75 * float(dados['#Rotação nominal'])

        # Imprimindo os valores percentuais de rotação na tabela resposta
        abaP2['B46'].value = rotacao25
        abaP2['B47'].value = rotacao50
        abaP2['B48'].value = rotacao75

        # Imprimindo os valores da OV (pdf) na planilha excel de saída
        abaP2['B13'].value = dados['#Potência']
        abaP2['B18'].value = dados['#Nív de montante normal']
        abaP2['B19'].value = dados['#Nív de jusante normal']
        abaP2['B17'].value = dados['#Afogamento (HS) requerido']
        abaP2['B16'].value = dados['#Queda líquida nominal']
        abaP2['B12'].value = dados['#Vazão nominal']
        abaP2['B20'].value = dados['#Rotação nominal']
        abaP2['B27'].value = dados['#Sobrepressão']
        abaP2['B26'].value = dados['#Sobrevelocidade']
        abaP2['B23'].value = dados['#Tempo de fecham distribuidor']
        abaP2['B22'].value = dados['#Tempo abertura distribuidor']
        abaP2['B24'].value = dados['#Tempo abertura VB']
        abaP2['B25'].value = dados['#Tempo fechamento VB']

        # Digitar manualamente "Rendimento" e "Queda bruta" caso não estejam na OV
        if dados['#Rendimento turbina'] == '' or dados['#Queda bruta'] == '':
            print('Digitar manualmente "Rendimento turbina" e "Queda bruta"')
        else:
            abaP2['B14'].value = dados['#Rendimento turbina']
            abaP2['B15'].value = dados['#Queda bruta']

        # Preenchendo as células da planilha resposta com o valor padrão 'SEM DOCUMENTO'
        abaP2['B29'].value = abaP2['B30'].value = abaP2['B31'].value = abaP2['B32'].value = abaP2['B33'].value = 'SEM DOCUMENTO'
        abaP2['B34'].value = abaP2['B35'].value = abaP2['B36'].value = abaP2['B37'].value = abaP2['B38'].value = 'SEM DOCUMENTO'
        abaP2['B39'].value = abaP2['B40'].value = abaP2['B41'].value = abaP2['B42'].value = abaP2['B43'].value = 'SEM DOCUMENTO'
        abaP2['B44'].value = abaP2['B45'].value = 'SEM DOCUMENTO'

        # Imprimindo os valores da planilha do PEP na planilha de saída
        for x in range(len(df['Descrição'])):
            for y in corteTurb:
                if y in df['Descrição'][x]:
                    abaP2['B29'].value = df['Documento'][x]
            for y in arranjoGer:
                if y in df['Descrição'][x]:
                    abaP2['B30'].value = df['Documento'][x]
            for y in qtt:
                if y in df['Descrição'][x]:
                    abaP2['B31'].value = df['Documento'][x]
            for y in valvBor:
                if y in df['Descrição'][x]:
                    abaP2['B32'].value = df['Documento'][x]
            for y in succao:
                if y in df['Descrição'][x]:
                    abaP2['B33'].value = df['Documento'][x]
            for y in preDist:
                if y in df['Descrição'][x]:
                    abaP2['B34'].value = df['Documento'][x]
            for y in dist:
                if y in df['Descrição'][x]:
                    abaP2['B35'].value = df['Documento'][x]
            for y in linhaEixo:
                if y in df['Descrição'][x]:
                    abaP2['B36'].value = df['Documento'][x]
            for y in vedEixo:
                if y in df['Descrição'][x]:
                    abaP2['B37'].value = df['Documento'][x]
            for y in manMont:
                if y in df['Descrição'][x]:
                    abaP2['B38'].value = df['Documento'][x]
            for y in manCom:
                if y in df['Descrição'][x]:
                    abaP2['B39'].value = df['Documento'][x]
            for y in descParadPart:
                if y in df['Descrição'][x]:
                    abaP2['B40'].value = df['Documento'][x]
            for y in manOpeManut:
                if y in df['Descrição'][x]:
                    abaP2['B41'].value = df['Documento'][x]
            for y in diagHidUHRV:
                if y in df['Descrição'][x]:
                    abaP2['B42'].value = df['Documento'][x]
            for y in esqEletUHRV:
                if y in df['Descrição'][x]:
                    abaP2['B43'].value = df['Documento'][x]
            for y in descFuncUHRV:
                if y in df['Descrição'][x]:
                    abaP2['B44'].value = df['Documento'][x]
            for y in skid:
                if y in df['Descrição'][x]:
                    abaP2['B45'].value = df['Documento'][x]

        # Salvando a planilha em outro arquivo diferente
        saida.save(self.pastaEsc + '/planilha_resposta_preenchida.xlsx')
        saida.save('planilha_resposta_preenchida.xlsx')

        # Abrindo a planilha resposta
        os.chdir(self.pastaEsc)
        os.system('start excel.exe planilha_resposta_preenchida.xlsx')

        # Fechamento do documento pdf
        pdfFileObj.close()

        # Fechamento do documento Excel
        saida.close()
