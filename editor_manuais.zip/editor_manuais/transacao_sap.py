import os
import time
import win32com.client

class Sap:
    def __init__(self, pep1, pep2, codOv):
        self.pep1 = pep1
        self.pep2 = pep2
        self.codOv = codOv

    def transacaoSap(self):
        try:
            # Inicia conexão no SAP
            self.SapGui = win32com.client.GetObject("SAPGUI").GetScriptingEngine
            self.session = self.SapGui.FindById("ses[0]")
            self.conexao = 'ok'
            print('Iniciando conexão com o SAP')

        except:
            self.conexao = 'erro'

        # Iniciando transação CV04N
        if self.conexao == 'ok':
            try:
                self.session.findById("wnd[0]").maximize
                self.session.findById("wnd[0]/tbar[0]/okcd").text = "/ncv04n"
                self.session.findById("wnd[0]/tbar[0]/btn[0]").press()
                self.session.findById("wnd[0]/tbar[1]/btn[13]").press()
                self.session.findById("wnd[0]/usr/tabsMAINSTRIP/tabpTAB4").select()
                self.session.findById("wnd[0]/usr/tabsMAINSTRIP/tabpTAB4/ssubSUBSCRN:SAPLCV100:0404/tabsOBJECTSTRIP/tabpOBJTB07").select()
                self.session.findById("wnd[0]/usr/tabsMAINSTRIP/tabpTAB4/ssubSUBSCRN:SAPLCV100:0404/tabsOBJECTSTRIP/tabpOBJTB07/ssubSUBSCRN_OBJLINK:SAPLCV100:1213/tblSAPLCV100TAB_X/ctxtMCDOKOB-PSPNR[0,0]").text = self.pep1
                self.session.findById("wnd[0]/usr/tabsMAINSTRIP/tabpTAB4/ssubSUBSCRN:SAPLCV100:0404/tabsOBJECTSTRIP/tabpOBJTB07/ssubSUBSCRN_OBJLINK:SAPLCV100:1213/tblSAPLCV100TAB_X/ctxtMCDOKOB-PSPNR[0,1]").text = self.pep2
                self.session.findById("wnd[0]/usr/tabsMAINSTRIP/tabpTAB4/ssubSUBSCRN:SAPLCV100:0404/tabsOBJECTSTRIP/tabpOBJTB07/ssubSUBSCRN_OBJLINK:SAPLCV100:1213/tblSAPLCV100TAB_X/ctxtMCDOKOB-PSPNR[0,1]").setFocus
                self.session.findById("wnd[0]/usr/tabsMAINSTRIP/tabpTAB4/ssubSUBSCRN:SAPLCV100:0404/tabsOBJECTSTRIP/tabpOBJTB07/ssubSUBSCRN_OBJLINK:SAPLCV100:1213/tblSAPLCV100TAB_X/ctxtMCDOKOB-PSPNR[0,1]").caretPosition = 15
                self.session.findById("wnd[0]/tbar[1]/btn[8]").press()
                self.session.findById("wnd[0]/tbar[1]/btn[5]").press()
                self.session.findById("wnd[0]/tbar[1]/btn[16]").press()
                self.session.findById("wnd[1]/tbar[0]/btn[0]").press()
                self.session.findById("wnd[1]/usr/ctxtDY_PATH").text = os.path.dirname(self.codOv)
                self.session.findById("wnd[1]/usr/ctxtDY_PATH").setFocus
                self.session.findById("wnd[1]/usr/ctxtDY_PATH").caretPosition = 31
                self.session.findById("wnd[1]/tbar[0]/btn[0]").press()

                self.download = 'ok'
            except:
                print('Não foi possível executar a transação CV04N.')
                print('Verifique se você informou os elementos PEP corretos e tente novamente.')

        elif self.conexao == 'erro':
            print('Erro na conexão:')
            print('Certifique-se de que realizou login no SAP.')

