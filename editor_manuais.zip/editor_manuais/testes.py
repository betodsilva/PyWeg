# ================================================
# Exemplo de PEP: 120-2000744-31 e 120-2000744-316
# ================================================

# Importa as bibliotecas necessárias
import os
import time
from tkinter import *
from tkinter import Tk
from tkinter import filedialog
from tkcalendar import DateEntry
from tkinter.filedialog import askopenfilename

# Importa os módulos criado para a aplicação
from transacao_sap import Sap
from compila_dados import Compilador
from impressor_doc import Impressor

def chama_transacao_sap():
    global valida_form, valida_num, campo_num
    valida_form = True
    valida_num = True

    nCliente = nomeCliente.get()
    nObra = nomeObra.get()
    nTurb = numTurb.get()
    ovTurb = codOvTurb.get()
    nExec = nomeExec.get()
    nVerif = nomeVerif.get()
    dProj = dataProj.get()
    dVer = dataVer.get()
    dCver = dataCver.get()
    cLitro = capLitro.get()
    pep1 = elemPEP1.get()
    pep2 = elemPEP2.get()
    codOv = ov
    docM1 = m1
    docM2 = m2
    docM3 = m3
    docM4 = m4
    pastaEsc = pasta_escolhida

    # Verificando se o tipo de digitado é numérico
    try:
        int(nTurb)
    except ValueError:
        valida_num = False
        campo_num = 'Preencha o campo "Quantidade de turbinas" com valor numérico inteiro.'

    try:
        float(cLitro)
    except ValueError:
        valida_num = False
        campo_num = 'Preencha o campo "Capacidade em litros da UHRV" com valor numérico separado ponto.'

    if nCliente == '' or nCliente == 'Digitar nome do cliente...':
        valida_form = False
    elif nObra == '' or nObra == 'Digitar nome da obra...':
        valida_form = False
    elif nTurb == '' or nTurb == 'Digitar...':
        valida_form = False
    elif ovTurb == '' or ovTurb == 'Digitar número...':
        valida_form = False
    elif nExec == '' or nExec == 'Digitar login...':
        valida_form = False
    elif nVerif == '' or nVerif == 'Digitar login...':
        valida_form = False
    elif dProj == '' or dProj == 'dd/mm/aaaa':
        valida_form = False
    elif dVer == '' or dVer == 'dd/mm/aaaa':
        valida_form = False
    elif dCver == '' or dCver == 'dd/mm/aaaa':
        valida_form = False
    elif cLitro == '' or cLitro == 'Digitar...':
        valida_form = False
    elif pep1 == '' or pep1 == 'Digitar código...':
        valida_form = False
    elif pep2 == '' or pep2 == 'Digitar código...':
        valida_form = False
    elif codOv == '' or codOv == 'Escolher...':
        valida_form = False
    elif docM1 == '' or docM1 == 'Escolher...':
        valida_form = False
    elif docM2 == '' or docM2 == 'Escolher...':
        valida_form = False
    elif docM3 == '' or docM3 == 'Escolher...':
        valida_form = False
    elif docM4 == '' or docM4 == 'Escolher...':
        valida_form = False
    elif pastaEsc == '' or pastaEsc == 'Escolher...':
        valida_form = False

    if valida_form == True and valida_num == True:
        a1 = Sap(pep1, pep2, codOv)
        a1.transacaoSap()

    elif valida_form == False:
        caixa_infos('Preencha todos os campos antes de prosseguir...', '')

    elif valida_num == False:
        caixa_infos(campo_num, '')

def chama_impressor_xlsx():
   nCliente = nomeCliente.get()
   nObra = nomeObra.get()
   nTurb = numTurb.get()
   ovTurb = codOvTurb.get()
   nExec = nomeExec.get()
   nVerif = nomeVerif.get()
   dProj = dataProj.get()
   dVer = dataVer.get()
   dCver = dataCver.get()
   cLitro = capLitro.get()
   docOv = ov
   pastaEsc = pasta_escolhida
   a2 = Compilador(nCliente, nObra, nTurb, ovTurb, nExec, nVerif, dProj, dVer, dCver, cLitro, docOv, pastaEsc)
   a2.lerPdf()

def chama_impressor_docx():
   docM1 = m1
   docM2 = m2
   docM3 = m3
   docM4 = m4
   nTurb = numTurb.get()
   pastaEsc = pasta_escolhida
   a3 = Impressor(docM1, docM2, docM3, docM4, pastaEsc, nTurb)
   a3.imprimeDoc()

# Cria a janela da interface gráfica
root = Tk()
root.title('Formulário para preenchimento de manuais de projeto.')
root.geometry('940x650')

#===============================================================================================================================
#========================================================= Frame 1 =============================================================
#===============================================================================================================================

frame1 = LabelFrame(root, borderwidth=1, relief='solid', text='  Informações do Projeto:  ')
frame1.place(x=10, y=10, width=300, height=550)

frameProj = LabelFrame(frame1, borderwidth=1, relief='solid', text='  Dados:  ')
frameProj.place(x=4, y=5, width=290, height=290)

def texto_temp_nomeCliente(e):
    if nomeCliente.get() == 'Digitar nome do cliente...':
        nomeCliente.delete(0, END)

    elif nomeCliente.get() == '':
        nomeCliente.insert(END, "Digitar nome do cliente...")

Label(frameProj, text='Nome do Cliente:').place(x=5, y=10)
nomeCliente = Entry(frameProj)
nomeCliente.insert(END, "Digitar nome do cliente...")
nomeCliente.place(x=120, y=10, width=150, height=20)
nomeCliente.bind("<FocusIn>", texto_temp_nomeCliente)
nomeCliente.bind("<FocusOut>", texto_temp_nomeCliente)

def texto_temp_nomeObra(e):
    if nomeObra.get() == 'Digitar nome da obra...':
        nomeObra.delete(0, END)

    elif nomeObra.get() == '':
        nomeObra.insert(END, 'Digitar nome da obra...')

Label(frameProj, text='Nome da Obra:').place(x=5, y=50)
nomeObra = Entry(frameProj)
nomeObra.insert(END, 'Digitar nome da obra...')
nomeObra.place(x=120, y=50, width=150, height=20)
nomeObra.bind("<FocusIn>", texto_temp_nomeObra)
nomeObra.bind("<FocusOut>", texto_temp_nomeObra)

def texto_temp_codOvTurb(e):
    if codOvTurb.get() == 'Digitar número...':
        codOvTurb.delete(0, END)

    elif codOvTurb.get() == '':
        codOvTurb.insert(END, "Digitar número...")

Label(frameProj, text='OV da turbina:').place(x=5, y=90)
codOvTurb = Entry(frameProj)
codOvTurb.insert(END, "Digitar número...")
codOvTurb.place(x=120, y=90, width=150, height=20)
codOvTurb.bind("<FocusIn>", texto_temp_codOvTurb)
codOvTurb.bind("<FocusOut>", texto_temp_codOvTurb)

def texto_temp_numTurb(e):
    if numTurb.get() == 'Digitar...':
        numTurb.delete(0, END)

    elif numTurb.get() == '':
        numTurb.insert(END, 'Digitar...')

Label(frameProj, text='Quantidade de\n turbinas:').place(x=5, y=120)
numTurb = Entry(frameProj)
numTurb.insert(END, "Digitar...")
numTurb.place(x=120, y=130, width=60, height=20)
numTurb.bind("<FocusIn>", texto_temp_numTurb)
numTurb.bind("<FocusOut>", texto_temp_numTurb)
Label(frameProj, text='Turbinas').place(x=190, y=130)

def texto_temp_capLitro(e):
    if capLitro.get() == 'Digitar...':
        capLitro.delete(0, END)

    elif capLitro.get() == '':
        capLitro.insert(END, 'Digitar...')

Label(frameProj, text='Capacidade em \nlitros da UHRV:').place(x=5, y=160)
capLitro = Entry(frameProj)
capLitro.insert(END, "Digitar...")
capLitro.place(x=120, y=170, width=60, height=20)
capLitro.bind("<FocusIn>", texto_temp_capLitro)
capLitro.bind("<FocusOut>", texto_temp_capLitro)
Label(frameProj, text='Litros').place(x=190, y=170)

def texto_temp_elemPEP1(e):
    if elemPEP1.get() == 'Digitar código...':
        elemPEP1.delete(0, END)

    elif elemPEP1.get() == '':
        elemPEP1.insert(END, 'Digitar código...')

Label(frameProj, text='Elemento PEP 1:').place(x=5, y=205)
elemPEP1 = Entry(frameProj)
elemPEP1.insert(END, "Digitar código...")
elemPEP1.place(x=120, y=205, width=150, height=20)
elemPEP1.bind("<FocusIn>", texto_temp_elemPEP1)
elemPEP1.bind("<FocusOut>", texto_temp_elemPEP1)

def texto_temp_elemPEP2(e):
    if elemPEP2.get() == 'Digitar código...':
        elemPEP2.delete(0, END)

    elif elemPEP2.get() == '':
        elemPEP2.insert(END, 'Digitar código...')

Label(frameProj, text='Elemento PEP 2:').place(x=5, y=240)
elemPEP2 = Entry(frameProj)
elemPEP2.insert(END, "Digitar código...")
elemPEP2.place(x=120, y=240, width=150, height=20)
elemPEP2.bind("<FocusIn>", texto_temp_elemPEP2)
elemPEP2.bind("<FocusOut>", texto_temp_elemPEP2)

frameExec = LabelFrame(frame1, borderwidth=1, relief='solid', text='  Execução:  ')
frameExec.place(x=4, y=300, width=290, height=220)

def texto_temp_nomeExec(e):
    if nomeExec.get() == 'Digitar login...':
        nomeExec.delete(0, END)

    elif nomeExec.get() == '':
        nomeExec.insert(END, 'Digitar login...')

Label(frameExec, text='Executor dos\n manuais:').place(x=5, y=5)
nomeExec = Entry(frameExec)
nomeExec.insert(END, 'Digitar login...')
nomeExec.place(x=120, y=10, width=150, height=20)
nomeExec.bind("<FocusIn>", texto_temp_nomeExec)
nomeExec.bind("<FocusOut>", texto_temp_nomeExec)

def texto_temp_nomeVerif(e):
    if nomeVerif.get() == 'Digitar login...':
        nomeVerif.delete(0, END)

    elif nomeVerif.get() == '':
        nomeVerif.insert(END, 'Digitar login...')

Label(frameExec, text='Verificador:').place(x=5, y=50)
nomeVerif = Entry(frameExec)
nomeVerif.insert(END, 'Digitar login...')
nomeVerif.place(x=120, y=50, width=150, height=20)
nomeVerif.bind("<FocusIn>", texto_temp_nomeVerif)
nomeVerif.bind("<FocusOut>", texto_temp_nomeVerif)

def texto_temp_dataProj(e):
    if dataProj.get() == 'dd/mm/aaaa':
        dataProj.delete(0, END)

    elif dataProj.get() == '':
        dataProj.insert(END, 'dd/mm/aaaa')

Label(frameExec, text='Data (projetado):').place(x=5, y=90)
dataProj = Entry(frameExec)
dataProj.insert(END, 'dd/mm/aaaa')
dataProj.place(x=120, y=90, width=100, height=20)
dataProj.bind("<FocusIn>", texto_temp_dataProj)
dataProj.bind("<FocusOut>", texto_temp_dataProj)

'''Label(frameExec, text='Data (projetado):').place(x=5, y=240)
dataProj = Entry(frameExec, width=15, bg="darkblue", fg="white", year=2022)
dataProj.place(x=120, y=240)'''

def texto_temp_dataVer(e):
    if dataVer.get() == 'dd/mm/aaaa':
        dataVer.delete(0, END)

    elif dataVer.get() == '':
        dataVer.insert(END, 'dd/mm/aaaa')

Label(frameExec, text='Data (VER):').place(x=5, y=130)
dataVer = Entry(frameExec)
dataVer.insert(END, 'dd/mm/aaaa')
dataVer.place(x=120, y=130, width=100, height=20)
dataVer.bind("<FocusIn>", texto_temp_dataVer)
dataVer.bind("<FocusOut>", texto_temp_dataVer)

'''Label(frameExec, text='Data (VER):').place(x=5, y=275)
dataVer = Entry(frameExec, width=15, bg="darkblue", fg="white", year=2022)
dataVer.place(x=120, y=275)'''

def texto_temp_dataCver(e):
    if dataCver.get() == 'dd/mm/aaaa':
        dataCver.delete(0, END)

    elif dataCver.get() == '':
        dataCver.insert(END, 'dd/mm/aaaa')

Label(frameExec, text='Data (CVER):').place(x=5, y=170)
dataCver = Entry(frameExec)
dataCver.insert(END, 'dd/mm/aaaa')
dataCver.place(x=120, y=170, width=100, height=20)
dataCver.bind("<FocusIn>", texto_temp_dataCver)
dataCver.bind("<FocusOut>", texto_temp_dataCver)

'''Label(frameExec, text='Data (CVER):').place(x=5, y=315)
dataCver = Entry(frameExec, width=15, bg="darkblue", fg="white", year=2022)
dataCver.place(x=120, y=315)'''

#===============================================================================================================================
#========================================================= Frame 2 =============================================================
#===============================================================================================================================

frame2 = LabelFrame(root, borderwidth=1, relief='solid', text='  Upload de Documentos:  ')
frame2.place(x=320, y=10, width=300, height=550)

# Frame do botão para escolher OV
frame_ov = LabelFrame(frame2, borderwidth=1, relief='solid', text='  Ordem de Venda:  ')
frame_ov.place(x=4, y=5, width=290, height=175)

def texto_temp_rendTurb(e):
    if rendTurb.get() == 'Digitar...':
        rendTurb.delete(0, END)

    elif rendTurb.get() == '':
        rendTurb.insert(END, 'Digitar...')

estCampos = 'disable'

Label(frame_ov, text='Nota: Preencher os campos abaixo caso não\n encontre as informações na OV.').place(x=5, y=0)
Label(frame_ov, text='Rendimento da Turbina:').place(x=5, y=45)
rendTurb = Entry(frame_ov, state=estCampos)
rendTurb.insert(END, "Digitar...")
rendTurb.place(x=170, y=45, width=55, height=20)
rendTurb.bind("<FocusIn>", texto_temp_rendTurb)
rendTurb.bind("<FocusOut>", texto_temp_rendTurb)
Label(frame_ov, text='%').place(x=230, y=45)

def texto_temp_quedaBruta(e):
    if quedaBruta.get() == 'Digitar...':
        quedaBruta.delete(0, END)

    elif quedaBruta.get() == '':
        quedaBruta.insert(END, 'Digitar...')

Label(frame_ov, text='Queda Bruta:').place(x=5, y=70)
quedaBruta = Entry(frame_ov, state=estCampos)
quedaBruta.insert(END, "Digitar...")
quedaBruta.place(x=170, y=70, width=55, height=20)
quedaBruta.bind("<FocusIn>", texto_temp_quedaBruta)
quedaBruta.bind("<FocusOut>", texto_temp_quedaBruta)
Label(frame_ov, text='metros').place(x=230, y=70)

ov = 'Escolher...'
def escolhe_ov():
   global ov
   ov = askopenfilename()
   texto_ov = Label(frame_ov, text='...'+ov[-27:])
   texto_ov.place(x=100, y=130)

Label(frame_ov, text='Escolha o Documento:').place(x=5, y=100)
btn_ov = Button(frame_ov, text='Escolher OV...', command=escolhe_ov)
btn_ov.place(x=195, y=100)

Label(frame_ov, text='Doc. escolhido:').place(x=5, y=130)
texto_ov = Label(frame_ov, text=ov)
texto_ov.place(x=100, y=130)

# Botão para escolher manual de comissionamento
frame_m1 = LabelFrame(frame2, borderwidth=1, relief='solid', text='  Manual de Comissionamento:  ')
frame_m1.place(x=4, y=185, width=290, height=80)

m1 = 'Escolher...'
def escolhe_manual1():
   global m1
   m1 = askopenfilename()
   texto_m1 = Label(frame_m1, text='...'+m1[-27:])
   texto_m1.place(x=100, y=35)

Label(frame_m1, text='Escolha o Documento:').place(x=5, y=5)
btn_m1 = Button(frame_m1, text='Escolher Manual...', command=escolhe_manual1)
btn_m1.place(x=170, y=5)

Label(frame_m1, text='Doc. escolhido:').place(x=5, y=35)
texto_m1 = Label(frame_m1, text=m1)
texto_m1.place(x=100, y=35)

# Botão para escolher descritivo de parada e partida
frame_m2 = LabelFrame(frame2, borderwidth=1, relief='solid', text='  Descritivo de Parada e Partida:  ')
frame_m2.place(x=4, y=270, width=290, height=80)

m2 = 'Escolher...'
def escolhe_manual2():
   global m2
   m2 = askopenfilename()
   texto_m2 = Label(frame_m2, text='...'+m2[-27:])
   texto_m2.place(x=100, y=35)

Label(frame_m2, text='Escolha o Documento:').place(x=5, y=5)
btn_m2 = Button(frame_m2, text='Escolher Descritivo...', command=escolhe_manual2)
btn_m2.place(x=160, y=5)

Label(frame_m2, text='Doc. escolhido:').place(x=5, y=35)
texto_m2 = Label(frame_m2, text=m2)
texto_m2.place(x=100, y=35)

# Botão para escolher descritivo de parada e partida
frame_m3 = LabelFrame(frame2, borderwidth=1, relief='solid', text='  Manual de Montagem:  ')
frame_m3.place(x=4, y=355, width=290, height=80)

m3 = 'Escolher...'
def escolhe_manual3():
   global m3
   m3 = askopenfilename()
   texto_m3 = Label(frame_m3, text='...'+m3[-27:])
   texto_m3.place(x=100, y=35)

Label(frame_m3, text='Escolha o Documento:').place(x=5, y=5)
btn_m3 = Button(frame_m3, text='Escolher Manual...', command=escolhe_manual3)
btn_m3.place(x=170, y=5)

Label(frame_m3, text='Doc. escolhido:').place(x=5, y=35)
texto_m3 = Label(frame_m3, text=m3)
texto_m3.place(x=100, y=35)

# Botão para escolher manual de operação e manutenção
frame_m4 = LabelFrame(frame2, borderwidth=1, relief='solid', text='  Manual de Operação e Manutenção:  ')
frame_m4.place(x=4, y=440, width=290, height=80)

m4 = 'Escolher...'
def escolhe_manual4():
    global m4
    m4 = askopenfilename()
    texto_m4 = Label(frame_m4, text='...'+m4[-27:])
    texto_m4.place(x=100, y=35)

Label(frame_m4, text='Escolha o Documento:').place(x=5, y=5)
btn_m4 = Button(frame_m4, text='Escolher Manual...', command=escolhe_manual4)
btn_m4.place(x=170, y=5)

Label(frame_m4, text='Doc. escolhido:').place(x=5, y=35)
texto_m4 = Label(frame_m4, text=m4)
texto_m4.place(x=100, y=35)

#===============================================================================================================================
#========================================================= Frame 3 =============================================================
#===============================================================================================================================

frame3 = LabelFrame(root, borderwidth=1, relief='solid', text='  Resultados:  ')
frame3.place(x=630, y=10, width=300, height=550)

pasta_escolhida = 'Escolher...'
def escolhe_pasta():
   global pasta_escolhida
   texto_pasta.config(text='')
   pasta_escolhida = filedialog.askdirectory()
   Label(frame_pasta, text=str(pasta_escolhida), wraplength=250).place(x=20, y=110)

frame_pasta = LabelFrame(frame3, borderwidth=1, relief='solid', text='  Salvar:  ')
frame_pasta.place(x=4, y=5, width=290, height=180)

Label(frame_pasta, text='Escolha uma pasta onde deseja salvar os arquivos').place(x=5, y=5)
Label(frame_pasta, text='no formato .docx editados.').place(x=5, y=25)

btn_pasta = Button(frame_pasta, text='Escolher Pasta...', command=escolhe_pasta)
btn_pasta.place(x=95, y=55)

Label(frame_pasta, text='Pasta de destino escolhida:').place(x=5, y=90)
texto_pasta = Label(frame_pasta, text='(Escolha uma pasta clicando no botão acima)')
texto_pasta.place(x=20, y=120)

frame_btn = LabelFrame(frame3, borderwidth=1, relief='solid', text='  Execução do Script:  ')
frame_btn.place(x=4, y=190, width=290, height=130)

# Botão de baixar planilha do PEP no SAP
btn_docx = Button(frame_btn, text='Baixar Dados do SAP', command=chama_transacao_sap)
btn_docx.place(x=87, y=10)

# Botão de verificar planilha excel
btn_xlsx = Button(frame_btn, text='Preencher Arquivo .XLSX', command=chama_impressor_xlsx)
btn_xlsx.place(x=75, y=40)

# Botão de verificar arquivo doc
btn_docx = Button(frame_btn, text='Alterar Arquivos .DOC', command=chama_impressor_docx)
btn_docx.place(x=82, y=70)

# Istruções de uso do programa
Label(frame3, text='INSTRUÇÕES DE USO:').place(x=5, y=335)
Label(frame3, text='1) Faça login no SAP antes de iniciar;').place(x=5, y=360)
Label(frame3, text='2) Preencha todos os campos no formulário;').place(x=5, y=380)
Label(frame3, text='3) Clique no botão "Baixar Dadps do SAP";').place(x=5, y=400)
Label(frame3, text='4) Confirme eventuais janelas do SAP;').place(x=5, y=420)
Label(frame3, text='5) Clique no botão "Preencher Arquivo .XLSX";').place(x=5, y=440)
Label(frame3, text='6) Confira os dados da planilha resposta;').place(x=5, y=460)
Label(frame3, text='7) Clique no botão "Alterar Arquivos .DOC";').place(x=5, y=480)
Label(frame3, text='8) Observe o andamento na caixa "Informações".').place(x=5, y=500)

#===============================================================================================================================
#============================================= Frame Caixa de Informações ======================================================
#===============================================================================================================================

# Preenche a caixa de informações com o texto inicial
if __name__ == '__main__':
    frame_infos = LabelFrame(root, borderwidth=1, relief='solid', text='  Informações:  ')
    frame_infos.place(x=10, y=565, width=920, height=70)

    linha1 = Label(frame_infos, text='Faça login no SAP, preencha todos os campos e escolha os arquivos e pasta antes de executar o programa.')
    linha1.place(x=8, y=5)
    linha2 = Label(frame_infos, text='')
    linha2.place(x=8, y=25)

# Preenche a caixa de informações com textos novos
def caixa_infos(t1, t2):
    global linha1, linha2

    frame_infos = LabelFrame(root, borderwidth=1, relief='solid', text='  Informações:  ')
    frame_infos.place(x=10, y=565, width=920, height=70)

    linha1.destroy()
    linha2.destroy()

    linha1 = Label(frame_infos, text=t1)
    linha1.place(x=8, y=5)
    linha2 = Label(frame_infos, text=t2)
    linha2.place(x=8, y=25)

root.mainloop()


# LEMBRAR:
# Terminar de implementar caixa de informações
# Implementar ativação/desativação dos três botões
# Implementar a ativação dos campos que faltarem na OV
# Corrigir bug ao rodar programa duas vezes sem reiniciar
