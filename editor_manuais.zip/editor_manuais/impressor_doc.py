from openpyxl import load_workbook
from docx import Document

class Impressor:
    def __init__(self, docM1, docM2, docM3, docM4, pastaEsc, nTurb):
        self.docM1 = docM1
        self.docM2 = docM2
        self.docM3 = docM3
        self.docM4 = docM4
        self.pastaEsc = pastaEsc
        self.nTurb = nTurb

    def imprimeDoc(self):
        # Carregando a planilha resposta preenchida (a versão da pasta escolhida)
        bd = load_workbook(self.pastaEsc + '/planilha_resposta_preenchida.xlsx')
        aba_1 = bd['P2']

        manuais = [self.docM1, self.docM2, self.docM3, self.docM4]
        for manual in manuais:
            # Carreganado documento do manual Word
            doc = Document(manual)

            # Percorrendo e lendo a coluna "B" da planilha resposta
            for x in range(47):
                celula = 'B' + str(x + 2)
                texto = str(aba_1[celula].value)
                c = '[' + celula + ']'

                # Percorrendo o texto normal do documento word
                for p in doc.paragraphs:
                    if c in p.text:
                        inline = p.runs
                        for i in range(len(inline)):
                            if c in inline[i].text:
                                text = inline[i].text.replace(c, texto)
                                inline[i].text = text
                            # Adicionando plural ou singular conforme o número de turbinas do projeto
                            elif float(self.nTurb) > 1 and '[s]' in inline[i].text:
                                text = inline[i].text.replace('[s]', 's')
                                inline[i].text = text
                            elif float(self.nTurb) > 1 and '[S]' in inline[i].text:
                                text = inline[i].text.replace('[S]', 'S')
                                inline[i].text = text
                            elif float(self.nTurb) == 1 and '[s]' in inline[i].text:
                                text = inline[i].text.replace('[s]', '')
                                inline[i].text = text
                            elif float(self.nTurb) == 1 and '[S]' in inline[i].text:
                                text = inline[i].text.replace('[S]', '')
                                inline[i].text = text
                            # Escrevendo o número de turbinas por extenso
                            if float(self.nTurb) == 1 and '[NUM]' in inline[i].text:
                                text = inline[i].text.replace('[NUM]', 'UMA')
                                inline[i].text = text
                            elif float(self.nTurb) == 2 and '[NUM]' in inline[i].text:
                                text = inline[i].text.replace('[NUM]', 'DUAS')
                                inline[i].text = text
                            elif float(self.nTurb) == 3 and '[NUM]' in inline[i].text:
                                text = inline[i].text.replace('[NUM]', 'TRÊS')
                                inline[i].text = text
                            elif float(self.nTurb) == 4 and '[NUM]' in inline[i].text:
                                text = inline[i].text.replace('[NUM]', 'QUATRO')
                                inline[i].text = text
                            elif float(self.nTurb) == 5 and '[NUM]' in inline[i].text:
                                text = inline[i].text.replace('[NUM]', 'CINCO')
                                inline[i].text = text

            # Percorrendo e lendo a coluna "B" da planilha resposta
            for x in range(47):
                celula = 'B' + str(x + 2)
                texto = str(aba_1[celula].value)
                c = '[' + celula + ']'

                # Percorrendo o texto das tabelas do documento word
                for table in doc.tables:
                    for row in table.rows:
                        for cell in row.cells:
                            for p in cell.paragraphs:
                                if c in p.text:
                                    inline = p.runs
                                    for i in range(len(inline)):
                                        print(inline[i].text)
                                        if c in inline[i].text:
                                            text = inline[i].text.replace(c, texto)
                                            inline[i].text = text
                                        # Adicionando plural ou singular conforme o número de turbinas do projeto
                                        elif float(self.nTurb) > 1 and '[s]' in inline[i].text:
                                            text = inline[i].text.replace('[s]', 's')
                                            inline[i].text = text
                                        elif float(self.nTurb) > 1 and '[S]' in inline[i].text:
                                            text = inline[i].text.replace('[S]', 'S')
                                            inline[i].text = text
                                        elif float(self.nTurb) == 1 and '[s]' in inline[i].text:
                                            text = inline[i].text.replace('[s]', '')
                                            inline[i].text = text
                                        elif float(self.nTurb) == 1 and '[S]' in inline[i].text:
                                            text = inline[i].text.replace('[S]', '')
                                            inline[i].text = text

            # Salva cada documento word depois de editado
            if manual == self.docM1:
                doc.save(self.pastaEsc + '/manual_comissionamento_fhs_cgh.docx')
            elif manual == self.docM2:
                doc.save(self.pastaEsc + '/descritivo_partida_parada_turbina_cgh_fhs.docx')
            elif manual == self.docM3:
                doc.save(self.pastaEsc + '/manual_montagem_fhs_balanço_sucção_curto.docx')
            elif manual == self.docM4:
                doc.save(self.pastaEsc + '/manual_operação_manutenção_fhs_cgh.docx')
