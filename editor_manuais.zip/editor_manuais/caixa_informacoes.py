# Importa as bibliotecas necessárias
import os
import time
from tkinter import *
from tkinter import Tk

class Informacoes:
    def __init__(self, t1, t2):
        self.t1 = t1
        self.t2 = t2

    def caixa_infos(self):

        linha1.destroy()
        linha1 = Label(frame_infos, text=self.t1)
        linha1.place(x=8, y=5)
        time.sleep(1)
        linha2.destroy()
        linha2 = Label(self.frame, text=self.t2)
        linha2.place(x=8, y=25)

        